//
//  Posts.swift
//  Course3FinalTask
//
//  Created by Надежда Зенкова on 24/06/2019.
//  Copyright © 2019 e-Legion. All rights reserved.
//

import UIKit

struct Posts {
    
    static var list: [Post] = []
    
}
