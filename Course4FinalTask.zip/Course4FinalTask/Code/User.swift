//
//  User.swift
//  Course2FinalTask
//
//  Created by Nadezhda Zenkova on 05/11/2018.
//  Copyright © 2018 e-Legion. All rights reserved.
//

import Foundation
